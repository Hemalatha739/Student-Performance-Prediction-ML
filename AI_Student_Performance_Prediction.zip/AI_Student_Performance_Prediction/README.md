# AI-Based Student Performance Prediction

A beginner-friendly machine-learning application that estimates a student's final exam score from study habits and academic indicators. It also displays a simple support recommendation.

## Features
- Predicts an estimated final score (0–100).
- Uses study hours, attendance, previous score, assignment completion, sleep, internet access and extracurricular participation.
- Trains a Random Forest regression model.
- Displays a simple performance outlook and recommendation.
- Includes a sample dataset and a Streamlit interface.

## Technology
Python · Pandas · Scikit-learn · Streamlit · Joblib

## Project structure
```text
AI_Student_Performance_Prediction/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── student_performance.csv
└── models/
    └── (generated after training)
```

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended):
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install packages: `pip install -r requirements.txt`
5. Train the model: `python train_model.py`
6. Start the application: `streamlit run app.py`

The app opens in your browser, usually at `http://localhost:8501`.

## Dataset note
The included CSV is a synthetic sample dataset created for demonstration and learning. It is not collected from real students and should not be used to make high-stakes academic decisions. Model metrics measure performance only on a held-out portion of this synthetic dataset.

## Future improvements
- Evaluate with a larger, consented real-world dataset.
- Add cross-validation and model comparison.
- Add student-wise history and downloadable reports.
- Improve fairness checks and explainability.

## Author
Hemalatha Bandila
