from pathlib import Path
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).parent
DATA_PATH = ROOT / "data" / "student_performance.csv"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
features = [
    "study_hours", "attendance", "previous_score", "assignments",
    "sleep_hours", "internet_access", "extracurricular"
]
X = df[features]
y = df["final_score"]

numeric = ["study_hours", "attendance", "previous_score", "assignments", "sleep_hours"]
categorical = ["internet_access", "extracurricular"]
preprocess = ColumnTransformer([
    ("numeric", "passthrough", numeric),
    ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical)
])

pipeline = Pipeline([
    ("preprocess", preprocess),
    ("model", RandomForestRegressor(n_estimators=250, random_state=42, min_samples_leaf=2))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)
pipeline.fit(X_train, y_train)
predictions = pipeline.predict(X_test)

print(f"Mean Absolute Error: {mean_absolute_error(y_test, predictions):.2f}")
print(f"R2 Score: {r2_score(y_test, predictions):.3f}")

joblib.dump(pipeline, MODEL_DIR / "performance_model.joblib")
print("Model saved to models/performance_model.joblib")
