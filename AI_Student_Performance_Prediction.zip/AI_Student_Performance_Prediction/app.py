import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

st.set_page_config(page_title="Student Performance Predictor", page_icon="🎓", layout="wide")
ROOT = Path(__file__).parent
MODEL_PATH = ROOT / "models" / "performance_model.joblib"

st.title("🎓 AI-Based Student Performance Predictor")
st.write("A machine-learning project that estimates a student's final score and identifies students who may need additional academic support.")
st.info("This is an educational demonstration using a sample dataset. Predictions are estimates, not official grades.")

if not MODEL_PATH.exists():
    st.warning("Model not found. Run `python train_model.py` first, then refresh this page.")
    st.stop()

model = joblib.load(MODEL_PATH)

st.sidebar.header("Enter Student Details")
study_hours = st.sidebar.slider("Daily study hours", 0.0, 12.0, 3.0, 0.5)
attendance = st.sidebar.slider("Attendance (%)", 0, 100, 80)
previous_score = st.sidebar.slider("Previous exam score (%)", 0, 100, 65)
assignments = st.sidebar.slider("Assignments completed (%)", 0, 100, 75)
sleep_hours = st.sidebar.slider("Sleep per day (hours)", 0.0, 12.0, 7.0, 0.5)
internet = st.sidebar.selectbox("Internet access", ["Yes", "No"])
extracurricular = st.sidebar.selectbox("Participates in extracurricular activities", ["Yes", "No"])

if st.button("Predict Student Performance", type="primary"):
    row = pd.DataFrame([{
        "study_hours": study_hours,
        "attendance": attendance,
        "previous_score": previous_score,
        "assignments": assignments,
        "sleep_hours": sleep_hours,
        "internet_access": internet,
        "extracurricular": extracurricular
    }])
    prediction = float(model.predict(row)[0])
    prediction = max(0, min(100, prediction))
    left, right = st.columns(2)
    left.metric("Estimated final score", f"{prediction:.1f}%")
    if prediction >= 75:
        right.success("Performance outlook: Strong")
        advice = "Maintain consistent study habits and continue completing assignments."
    elif prediction >= 50:
        right.warning("Performance outlook: Moderate")
        advice = "Create a regular revision plan and improve attendance or assignment completion."
    else:
        right.error("Performance outlook: Needs support")
        advice = "Consider extra practice, teacher guidance, and a structured daily study schedule."
    st.subheader("Suggested action")
    st.write(advice)

st.divider()
st.subheader("Project workflow")
st.write("Student details → Data preprocessing → Random Forest regression model → Estimated score → Support recommendation")
st.caption("Built with Python, Pandas, Scikit-learn, Joblib and Streamlit.")
